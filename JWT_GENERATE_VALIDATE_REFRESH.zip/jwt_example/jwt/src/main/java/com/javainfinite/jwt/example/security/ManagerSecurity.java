package com.javainfinite.jwt.example.security;

import com.javainfinite.jwt.example.filter.JwtTokenCreator;
import com.javainfinite.jwt.example.filter.JwtTokenValidator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@Configuration
public class ManagerSecurity extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).
                and()
                .addFilterAfter(new JwtTokenCreator(), BasicAuthenticationFilter.class)
                .addFilterBefore(new JwtTokenValidator(), BasicAuthenticationFilter.class)
                .authorizeRequests()
                .antMatchers("/getAllManagers").authenticated()
                .antMatchers("/register").permitAll()
                .antMatchers("/login").permitAll()
                .antMatchers("/registeredUsers").authenticated()
                .antMatchers("/refresh").permitAll()
                .antMatchers("/saveManager").authenticated().and()
                .cors().disable()
                .csrf().disable()
                .httpBasic();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
