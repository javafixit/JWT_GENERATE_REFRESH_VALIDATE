package com.javainfinite.jwt.example.service;

import com.javainfinite.jwt.example.model.Registration;
import com.javainfinite.jwt.example.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RegistrationService {

    @Autowired
    private RegistrationRepository repository;


    public Registration register(Registration registration){

        return repository.save(registration);
    }

    public List<Registration> getAllRegisteredUsers(){
        return repository.findAll();
    }




}
