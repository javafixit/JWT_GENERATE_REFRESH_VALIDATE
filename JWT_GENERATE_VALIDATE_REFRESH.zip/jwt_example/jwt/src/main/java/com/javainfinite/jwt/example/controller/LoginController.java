package com.javainfinite.jwt.example.controller;

import com.javainfinite.jwt.example.model.Registration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
public class LoginController {

    Logger logger = LoggerFactory.getLogger(LoginController.class);

    @PostMapping("/login")
    public String login() {
        logger.info("Successfully Logged in with Username: {}", SecurityContextHolder.getContext().getAuthentication().getName());
        return "Successfully Logged in with Username: "+SecurityContextHolder.getContext().getAuthentication().getName();
    }

}
