package com.javainfinite.jwt.example.controller;

import com.javainfinite.jwt.example.model.Manager;
import com.javainfinite.jwt.example.model.Registration;
import com.javainfinite.jwt.example.repository.ManagerRepository;
import com.javainfinite.jwt.example.service.ManagerService;
import com.javainfinite.jwt.example.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ManagerController {

    @Autowired
    private ManagerService service;

    @Autowired
    private PasswordEncoder encoder;

    @Autowired
    private RegistrationService registrationService;

    @GetMapping("/saveManager")
    public Manager saveManager() {
        Manager manager = new Manager();
        manager.setManagerCode("mg001");
        manager.setManagerName("Mr.Alpha");
        manager.setManagerDepartment("Human Resources");
        return service.save(manager);
    }

    @GetMapping("/getAllManagers")
    public List<Manager> getAllManagers() {
        return service.getAll();
    }


    @PostMapping("/register")
    public Registration register(@RequestBody Registration registration) {
        Registration registrationDTO = new Registration();
        registrationDTO.setUsername(registration.getUsername());
        registrationDTO.setPassword(encoder.encode(registration.getPassword()));
        return registrationService.register(registrationDTO);
    }

    @GetMapping("/registeredUsers")
    public List<Registration> getRegisteredUsers() {
        return registrationService.getAllRegisteredUsers();
    }

}