package com.javainfinite.jwt.example.util;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;
import java.util.Date;

public class JwtTokenGenerator {

    Logger logger = LoggerFactory.getLogger(JwtTokenGenerator.class);

    private final String JWT_HEADER = "Authorization";
    private final String JWT_KEY = "jxgEQe.XHuPq8VdbyYFNkAN.dudQ0903YUn4";

    public void generateToken(HttpServletRequest request, HttpServletResponse response) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication != null) {
            logger.info("Authentication is not null");
            SecretKey key = Keys.hmacShaKeyFor(JWT_KEY.getBytes(StandardCharsets.UTF_8));
            String jwtToken = Jwts.builder().setIssuer("vikram")
                    .setSubject("Jwt Token")
                    .claim("username", authentication.getName())
                    .setIssuedAt(new Date())
                    .setExpiration(new Date((new Date()).getTime() + 30000))
                    .signWith(key).compact();

            if (request.getHeader("RefreshToken") == null) {
                String refreshJwt = Jwts.builder().setIssuer("vikram")
                        .setSubject("Jwt Token")
                        .claim("username", authentication.getName())
                        .setIssuedAt(new Date())
                        .setExpiration(new Date((new Date()).getTime() + 3000000))
                        .signWith(key).compact();
                response.setHeader("RefreshToken", refreshJwt);
                logger.info("Refresh Token successfully generated: {}", refreshJwt);
            }

            response.setHeader(JWT_HEADER, jwtToken);
            logger.info("Token successfully generated: {}", jwtToken);
        }
    }
}
