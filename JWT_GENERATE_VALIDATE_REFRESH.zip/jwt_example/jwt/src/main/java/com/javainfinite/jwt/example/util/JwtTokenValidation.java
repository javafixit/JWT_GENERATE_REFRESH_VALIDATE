package com.javainfinite.jwt.example.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.context.SecurityContextHolder;

import javax.crypto.SecretKey;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;

public class JwtTokenValidation {

    private final String JWT_HEADER = "Authorization";
    private final String JWT_KEY = "jxgEQe.XHuPq8VdbyYFNkAN.dudQ0903YUn4";

    Logger logger = LoggerFactory.getLogger(JwtTokenValidation.class);

    public void tokenValidation(HttpServletRequest request, HttpServletResponse response) {

        logger.info("Validating JWT Token");
        String jwtToken = request.getHeader("Authorization");

        if (null != jwtToken && !jwtToken.contains("Basic")) {
            try {
                SecretKey key = Keys.hmacShaKeyFor(
                        JWT_KEY.getBytes(StandardCharsets.UTF_8));

                Claims claims = Jwts.parserBuilder()
                        .setSigningKey(key)
                        .build()
                        .parseClaimsJws(jwtToken)
                        .getBody();
                String username = String.valueOf(claims.get("username"));
                String authorities = (String) claims.get("authorities");
                Authentication auth = new UsernamePasswordAuthenticationToken(username, null,
                        AuthorityUtils.commaSeparatedStringToAuthorityList(authorities));
                SecurityContextHolder.getContext().setAuthentication(auth);

            } catch (ExpiredJwtException ex) {
                logger.info("JWT Token Expired");
            } catch (Exception e) {
                throw new BadCredentialsException("Invalid Token received!");
            }

        }
    }

    public void validateRefreshToken(HttpServletRequest request, HttpServletResponse response) {
        logger.info("Validating Refresh Token...");
        if (request.getHeader("RefreshToken") == null) {
            throw new BadCredentialsException("Token not available, Please relogin");
        }
        String refreshToken = request.getHeader("RefreshToken");

        try {
            SecretKey key = Keys.hmacShaKeyFor(
                    JWT_KEY.getBytes(StandardCharsets.UTF_8));

            Claims claims = Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(refreshToken)
                    .getBody();

            logger.info("Succdssfully validated Refresh token, user is valid: {}", claims.get("username"));
        } catch (ExpiredJwtException ex) {
            logger.info("JWT Token Expired");
        } catch (Exception e) {
            throw new BadCredentialsException("Invalid Token received!");
        }
        logger.info("Completed refresh token validation");
    }
}
